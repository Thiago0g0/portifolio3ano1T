/*let i =0;
while (i <= 5) {

} */
function tabu(numero){
for (let i = 1; i <= 10; i++) {
    const resultado = numero * i
    console.log(` ${numero} x ${1} - ${resultado}`)
}
}
tabu(4)
