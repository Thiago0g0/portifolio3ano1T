/*QUADRADO
var assert = require('assert');

var lado, base, area;
lado = ;
base = ;
console.log('A área do é:')

area = lado * base;
console.log(area); */

function areaQuadrado(lado){
  console.log(`$(lado * lado)`)
}

function areaLosango(Dmaior, Dmenor){
  console.log(`$(Dmaior * Dmenor))`)
}

function areaCirculo(raio){
  console.log(`$(3,14 * (raio * raio))`)
}

function areaTriangulo(base , altura){
  console.log(`$(base * altura) / 2 )`)
}

function areaTrapezio(bmaior + bmenor, altura){
  console.log(`$(bmaior = bmenor))`)
}

areaCirculo(4)
areaLosango(10,6)
areaQuadrado(5)
areaTrapezio(8,4,5)


