/*function uber(){
    var uber = (trabalho)
    if (estrada + direita)
    return (trabalho)
 
   var uber =(escola)
   if (estrada + esquerda)
    return (escola)
}
console.log(uber)*/


/*var direcao ='direita'
if(direcao == "direita"){
    console.log("trabaho")
}else{
    console.log("escola")
}*/

function uber(direcao){
    if(direcao == "direita"){
        console.log("Indo ao trabalho")
    }else{
        console.log("ir a escola")
    }
}
uber()
