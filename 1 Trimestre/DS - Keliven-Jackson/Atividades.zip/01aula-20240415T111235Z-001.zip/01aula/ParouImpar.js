function par(num){
    if(num % 2 === 0){
    console.log("par")
}
        else{
            console.log("impar")
        }
}
par(4)